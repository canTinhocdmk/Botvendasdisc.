Altere os webhooks noccomando de reembolso
altere o webhook na index de vendas
altere o webhook na index de bot online
altere os arquivos na config.json
